function [mt_board] = make_board(r,c) 
    ones_board = ones(r,c);
    mt_board = ones_board * [' '];
end
 
